void setup() {
  Serial.begin(9600);
}

void loop() {
  Serial.println("RFID Smart Cart System Running...");
  delay(1000);
}

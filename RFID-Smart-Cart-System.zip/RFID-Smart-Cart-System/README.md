# RFID-Based Smart Shopping Cart System

This project is developed using Arduino Uno and RFID technology for automated smart billing in shopping malls.

## Components Used
- Arduino Uno
- MFRC522 RFID Module
- LCD Display
- IR Sensor
- Buzzer

## Features
- Automatic product detection
- Smart billing system
- LCD display output
- RFID-based identification

## Technologies
Arduino, Embedded Systems, IoT

## Author
Srinivas C
